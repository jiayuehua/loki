#include "bumpalloc.h"
#include "nestedheap.h"
#include "xallocheap.h"
#include "zoneheap.h"

// Deprecated:
//#include "obstack.h"
//#include "obstackheap.h"
//#include "obstackreap.h"
